/* WARNING! All changes made to this file will be lost! */

#ifndef __IBEX_SETTING_H__
#define __IBEX_SETTING_H__

#define _IBEX_RELEASE_ "2.8.7"
#define _IBEX_INTERVAL_LIB_ "FILIB"
#define _IBEX_LP_LIB_ "NONE"

#endif /* __IBEX_SETTING_H__ */
