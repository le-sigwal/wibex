/* WARNING! All changes made to this file will be lost! */

#ifndef __IBEX_SETTING_H__
#define __IBEX_SETTING_H__

#define _IBEX_RELEASE_ "2.6.0"
#define _IBEX_INTERVAL_LIB_ "FILIB"
#define _IBEX_LP_LIB_ "NONE"
#define _IBEX_WITH_SOLVER_ 1

#endif /* __IBEX_SETTING_H__ */
